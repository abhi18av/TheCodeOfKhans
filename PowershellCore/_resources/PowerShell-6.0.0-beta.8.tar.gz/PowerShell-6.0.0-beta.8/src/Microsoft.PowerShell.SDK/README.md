Microsoft PowerShell SDK
========================

This is a meta-project that serves two purposes:

1. Group PowerShell sub projects to avoid unnecessary duplication of reference declarations.
2. Group extra .NET Core packages that PowerShell doesn't depend on directly but must provide for our users at runtime.

