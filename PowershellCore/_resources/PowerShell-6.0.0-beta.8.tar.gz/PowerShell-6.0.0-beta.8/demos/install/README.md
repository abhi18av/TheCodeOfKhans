﻿## Install demo

For Windows refer to the [installation instructions](https://github.com/PowerShell/PowerShell/blob/master/docs/installation/windows.md)

For Linux, using [download.sh](https://github.com/PowerShell/PowerShell/blob/master/tools/download.sh) is the best way to deploy PowerShell bits